<?php
return [
    "news1_title" => "hyyyy",
    "news1_body" => "blah blah blah",
];